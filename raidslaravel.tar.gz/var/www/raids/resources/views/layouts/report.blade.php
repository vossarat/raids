<!DOCTYPE html>
<html lang="en">

	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

		<!-- additional CSS -->
		<link rel="stylesheet" href="{{ asset('css/report.css') }}"/>

	</head>

	<body>		
		@yield('content')
	</body>
	
</html>