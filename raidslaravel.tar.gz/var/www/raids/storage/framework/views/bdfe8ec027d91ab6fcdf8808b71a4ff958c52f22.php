<?php $__env->startSection('content'); ?>

<h1 class="page-header">Отчеты. Форма №4</h1>

<div class="col-md-8 col-md-offset-2">
	<div class="panel panel-default">
		<div class="panel-heading"> 
			Форма №4
			<a href="<?php echo e(route('index.index')); ?>" class="close" data-dismiss="alert" aria-hidden="true">&times;</a> 
		</div>

		<div class="panel-body">
			<form class="form-horizontal" role="form" method="POST" action="/reports/form4">
				<?php echo e(csrf_field()); ?>			
				
				<div class="form-group"> 
				
						
						<label for="startdate" class="col-md-3 col-md-offset-1 control-label">Отчетный период с</label>
						<div class="col-md-2">
							<input id="startdate" type="text" class="form-control" name="startdate" value="">
						</div>
						
						
						
						<label for="enddate" class="col-md-1 control-label">по</label>
						<div class="col-md-2">
							<input id="enddate" type="text" class="form-control" name="enddate" value="">
						</div>
						
						
				</div>
				
				<div class="form-group">						
					<label for="region" class="col-md-3 col-md-offset-1 control-label">ЛПУ</label>							
					<div class="col-md-5">
						<select class="form-control" name="region">									
							<?php $__currentLoopData = $referenceRegion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if($item->id == 0): ?>
									<option value="<?php echo e($item->id); ?>">По всем регионам</option>
								<?php else: ?>
									<option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
								<?php endif; ?>								
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>			
						</select>
					</div>
				</div> 
				
				
				<div class="form-group">
					<label for="radio" class="col-md-3 col-md-offset-1 control-label">Вывод на:</label>
					<div class="col-md-2">	
						<label class="radio text-center">
							<input type="radio" name="output" value="toScreen" checked="checked"> Экран
						</label>
					</div>

					<div class="col-md-2">		
						<label class="radio">
							<input type="radio" name="output" value="toExcel"> Excel
						</label>
					</div> 
				</div> 
				
				<div class="form-group">
					<div class="col-md-3 col-md-offset-3">
						<button type="submit" class="btn btn-primary">
							Сформировать
						</button>
					</div>
				</div>

			</form>
		</div>
	</div>
</div>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('js/jquery.maskedinput.js')); ?>"></script>
<script src="<?php echo e(asset('js/maskinputdate.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>