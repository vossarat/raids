<div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
	<label for="name" class="col-md-4 control-label">Наименование МО</label>

	<div class="col-md-6">
		<input id="name" type="text" class="form-control" name="name" value="<?php echo e(isset($viewdata->name) ? $viewdata->name : old('name')); ?>" required>

		<?php if($errors->has('name')): ?>
		<span class="help-block">
			<strong>
				<?php echo e($errors->first('name')); ?>

			</strong>
		</span>
		<?php endif; ?>
	</div>
</div>

<div class="form-group">
	<div class="<?php echo e($errors->has('parent_id') ? ' has-error' : ''); ?>"> 
		
		<label for="parent_id" class="col-md-4 control-label">Подчиненность</label>		
		
		<div class="col-md-6">
		<select class="form-control" name="parent_id">		
			<?php $__currentLoopData = $referenceRegion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if(isset($viewdata)): ?>
					<option <?php echo e($viewdata->parent_id == $item->id ? 'selected' : ''); ?> value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
				<?php else: ?>
					<option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
				<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>			
		</select>

		<?php if($errors->has('parent_id')): ?>
		<span class="help-block">
			<strong>
				<?php echo e($errors->first('parent_id')); ?>

			</strong>
		</span>
		<?php endif; ?>
		</div>
	</div>
</div>

<div class="form-group">
	<div class="<?php echo e($errors->has('city_id') ? ' has-error' : ''); ?>"> 
		
		<label for="city_id" class="col-md-4 control-label">Местонахождение</label>		
		
		<div class="col-md-6">
		<select class="form-control" name="city_id">		
			<?php $__currentLoopData = $referenceCity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if(isset($viewdata)): ?>
					<option <?php echo e($viewdata->city_id == $item->id ? 'selected' : ''); ?> value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
				<?php else: ?>
					<option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
				<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>			
		</select>

		<?php if($errors->has('city_id')): ?>
		<span class="help-block">
			<strong>
				<?php echo e($errors->first('city_id')); ?>

			</strong>
		</span>
		<?php endif; ?>
		</div>
	</div>
</div>

<div class="form-group">
	<div class="<?php echo e($errors->has('weight') ? ' has-error' : ''); ?>"> 
		
		<label for="weight" class="col-md-4 control-label">Порядок</label>

		<div class="col-md-2">
			<input id="weight" type="text" class="form-control" name="weight" value="<?php echo e(isset($viewdata->weight) ? $viewdata->weight : old('weight')); ?>">
			<?php if($errors->has('weight')): ?>
			<span class="help-block">
				<strong>
					<?php echo e($errors->first('weight')); ?>

				</strong>
			</span>
			<?php endif; ?>
		</div>
	</div> 
</div>			