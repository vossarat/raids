<?php $__env->startSection('content'); ?>

	<h1 class="page-header">Код</h1>

	<div class="col-md-8 col-md-offset-2">
		<div class="panel panel-default">
			<div class="panel-heading"> 
				Добавить код
				<a href="<?php echo e(route('code.index')); ?>" class="close" data-dismiss="alert" aria-hidden="true">&times;</a> 
			</div>

			<div class="panel-body">
				<form class="form-horizontal" role="form" method="POST" action="<?php echo e(route('code.store')); ?>">
					<?php echo e(csrf_field()); ?>


					<?php echo $__env->make('code.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

					<div class="form-group">
						<div class="col-md-6 col-md-offset-4">
							<button type="submit" class="btn btn-primary">
								Добавить
							</button>
						</div>
					</div>

				</form>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>