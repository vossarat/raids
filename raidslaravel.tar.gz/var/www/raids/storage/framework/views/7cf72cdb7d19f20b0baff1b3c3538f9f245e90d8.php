<div class="form-group"> 
	<div class="<?php echo e($errors->has('code') ? ' has-error' : ''); ?>"> 
		
		<label for="code" class="col-md-4 control-label">Код</label>

		<div class="col-md-2">
			<input id="code" type="text" class="form-control" name="code" value="<?php echo e(isset($viewdata->code) ? $viewdata->code : old('code')); ?>">
			<?php if($errors->has('code')): ?>
			<span class="help-block">
				<strong>
					<?php echo e($errors->first('code')); ?>

				</strong>
			</span>
			<?php endif; ?>
		</div>
	</div> 
</div>	

<div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>"> 
	<label for="name" class="col-md-4 control-label">Наименование</label>

	<div class="col-md-6">
		<input id="name" type="text" class="form-control" name="name" value="<?php echo e(isset($viewdata->name) ? $viewdata->name : old('name')); ?>" required>

		<?php if($errors->has('name')): ?>
		<span class="help-block">
			<strong>
				<?php echo e($errors->first('name')); ?>

			</strong>
		</span>
		<?php endif; ?>
	</div>
</div> 


<div class="form-group"> 
	<div class="<?php echo e($errors->has('weight') ? ' has-error' : ''); ?>"> 
		
		<label for="weight" class="col-md-4 control-label">Порядок</label>

		<div class="col-md-2">
			<input id="weight" type="text" class="form-control" name="weight" value="<?php echo e(isset($viewdata->weight) ? $viewdata->weight : old('weight')); ?>">
			<?php if($errors->has('weight')): ?>
			<span class="help-block">
				<strong>
					<?php echo e($errors->first('weight')); ?>

				</strong>
			</span>
			<?php endif; ?>
		</div>
	</div> 
</div>	