<html>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="<?php echo e(asset('css/table.css')); ?>"/>

<table>
	<thead>
		<tr>
			<th>#</th>
			<th>Фамилия И.О.</th>
			<th>Пол</th>
			<th>Дата рождения</th>
			<th>Местонахождение</th>
			<th>Дата</th>
			<th>Регион</th>
		</tr>
	</thead>
	<tbody>
		<?php $__currentLoopData = $viewdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($patient->number); ?></td>
			<td><?php echo e($patient->surname.' '.mb_substr($patient->name,0,1,"UTF-8").mb_substr($patient->middlename,0,1,"UTF-8")); ?></td>
			<td><?php echo e($patient->sex[0]->name); ?></td>
			<td><?php echo e(date('d-m-Y',strtotime($patient->birthday))); ?></td>
			<td><?php echo e($patient->city[0]->name); ?></td>
			<td><?php echo e($patient->grantdate->format('d-m-Y')); ?></td>
			<td><?php echo e($patient->region[0]->name); ?></td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	</tbody>
</table>


</html>


