<!DOCTYPE html>
<html lang="en">

	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

		<!-- additional CSS -->
		<link rel="stylesheet" href="<?php echo e(asset('css/report.css')); ?>"/>

	</head>

	<body>		
		<?php echo $__env->yieldContent('content'); ?>
	</body>
	
</html>