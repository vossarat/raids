<?php $__env->startSection('content'); ?>
<h1 class="page-header">Коды</h1>

<div class="form-group">
	<form action="<?php echo e(route('code.create')); ?>">

			<button type="submit" class="btn btn-primary">
				<i class="fa fa-plus"></i> Добавить
			</button>

	</form>
</div>

<?php if(Session::has('message')): ?>
<div class="alert alert-success">
	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
	<?php echo e(Session::get('message')); ?>

</div>
<?php endif; ?>


<table class="table table-condensed table-striped table-scroll">
	<thead>
		<tr>
			<th class="col-sm-4 text-center">Код</th>
			<th class="col-sm-4 text-center">Наименование</th>
			<th class="col-sm-2 text-center">Порядок</th>
			<th class="col-sm-2" colspan="2">Действие</th>
		</tr>
	</thead>
	<tbody>
		<?php $__currentLoopData = $viewdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td class="col-sm-4 text-center"><?php echo e($code->code); ?></td>
			<td class="col-sm-4 text-center"><?php echo e($code->name); ?></td>
			<td class="col-sm-2 text-center"><?php echo e($code->weight); ?></td>
			<td class="col-sm-1">     
                <form action="<?php echo e(route('code.edit', $code->id)); ?>">
                	<button type="submit" class="btn-action"><i class="fa fa-edit"></i></button>
                </form>
            </td>
			<td class="col-sm-1">
				<form action="<?php echo e(route('code.destroy', $code->id)); ?>" method="POST">
                    <input type="hidden" name="_method" value="DELETE">
                    <?php echo e(csrf_field()); ?>

                    <button type="submit" class="btn-action"><i class="fa fa-trash"></i></button>
                </form>
           </td>
           
            
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	</tbody>
</table>

<?php $__env->startPush('css'); ?>
	<link rel="stylesheet" href="<?php echo e(asset('css/table.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>