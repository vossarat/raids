<ul class="nav">	
	<li>
		<a href="/"><i class="fa fa-file fa-5x"></i>
			<p>Карта</p>
		</a>
	</li>
	<li>
		<a href="/setup"><i class="fa fa-cog fa-5x"></i>
			<p>Настройка</p>
		</a>
	</li>
	<li>
		<a href="/phpmyadmin"><i class="fa fa-table fa-5x"></i>
			<p>PHPMyAdmin</p>
		</a>
	</li>
</ul>