<?php $__env->startSection('content'); ?>
<h1 class="page-header">Установка программы</h1>

<div class="row"> 
	<form class="form-inline" role="form" method="POST" action="<?php echo e(url('/setup/make/reference')); ?>">
		<?php echo e(csrf_field()); ?>

		
		<div class="col-md-4">
			<div class="form-group">			
				<button type="submit" class="btn <?php echo e($isReferences ? 'btn-danger':'btn-primary'); ?> btn-lg">
					<?php echo e($isReferences ? 'Удаление ':'Создание '); ?> справочников
				</button>
			</div>
		</div>
		
		<div class="col-md-8">
				<?php if($errors->has('reference')): ?>
					<div class="alert alert-warning">
						<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
						<?php echo e($errors->first('reference')); ?>

					</div>			
				<?php endif; ?>
		</div>
	</form>
</div> 

<div class="row"> 
	<form class="form-inline" role="form" method="POST" action="<?php echo e(url('/setup/make/register')); ?>">
		<?php echo e(csrf_field()); ?>

		
		<div class="col-md-4">		
			<button type="submit" class="btn <?php echo e($isTableRegister ? 'btn-danger':'btn-primary'); ?> btn-lg">
				<?php echo e($isTableRegister ? 'Удаление ':'Создание '); ?> таблицы регистра
			</button>
		</div>
		
		<div class="col-md-8">			
			<?php if($errors->has('create')): ?>
				<div class="alert alert-warning">
					<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
					<?php echo e($errors->first('create')); ?>

				</div>			
			<?php endif; ?>
		</div>
	</form>
</div> 



<div class="row">
	<form class="form-inline" role="form" method="POST" action="<?php echo e(route('append')); ?>" enctype="multipart/form-data">
		<?php echo e(csrf_field()); ?>


		<div class="form-group">					
			<div class="col-md-4">
				<button type="submit" class="btn btn-primary btn-lg">
					Заполнить
				</button>
			</div>
		</div>
		
		<div class="form-group">			
			<div class="col-md-4">
				<input type="file" name="filedbf"/>
			</div>
		</div>
		
		<div class="form-group">	
			<div class="col-md-4">
				<?php if($errors->has('append')): ?>
					<div class="alert alert-warning">
						<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
						<?php echo e($errors->first('append')); ?>

					</div>			
				<?php endif; ?>
			</div>			
		</div>

	</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>