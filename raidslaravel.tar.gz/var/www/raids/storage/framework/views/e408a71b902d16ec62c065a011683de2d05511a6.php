<?php $__env->startSection('content'); ?>

<table>
	<tr>
		<td colspan="6" class="noborder center">Отчет по 4-ой фоpме</td>
	</tr>
	<tr>
		<td colspan="6" class="noborder">Отчетный период: <?php echo e($startdate.' - '.$enddate); ?></td>
	</tr>
	<tr>
		<td colspan="6" class="noborder">Наименование региона (ЛПУ): <?php echo e($region); ?></td>
	</tr>
</table>

<table>
	<thead>
		<tr>
			<th>Код</th>
			<th>Контингент обследуемых</th>
			<th>Мужчин</th>
			<th>Женщин</th>
			<th>Не указан</th>
			<th>Всего</th>
		</tr>
	</thead>
	<tbody>
		<?php $__currentLoopData = $viewdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($code->code.' - '); ?></td>
			<td><?php echo e($code->codename); ?></td>
			<td><?php echo e($code->mens); ?></td>
			<td><?php echo e($code->womens); ?></td>
			<td><?php echo e($code->notspecified); ?></td>
			<td><?php echo e($code->total); ?></td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.report', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>