$(document).ready(function()
	{
		$("#birthday").mask("99-99-9999", {placeholder: "дд-мм-гггг" });
		$("#grantdate").mask("99-99-9999", {placeholder: "дд-мм-гггг" });
		$("#startdate").mask("99-99-9999", {placeholder: "дд-мм-гггг" });
		$("#enddate").mask("99-99-9999", {placeholder: "дд-мм-гггг" });
	});